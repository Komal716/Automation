package com.automation.framework.step.definition;


import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class Account {

	WebDriver driver;
	
	
	@Given("^User Login to application$")
	public void user_Login_to_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().deleteAllCookies();
		driver.get("http://automationpractice.com/index.php");
		
	}

	@When("^User Navigate to Sign in page$")
	public void user_Navigate_to_Sign_in_page() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")).click();
		Thread.sleep(3000);
	}

	@Then("^User Creates New Account$")
	public void user_Creates_New_Account() throws Throwable {

		driver.findElement(By.xpath("//*[@id=\"email_create\"]")).sendKeys("Ganesh_av19@yahoo.com");
		driver.findElement(By.xpath("//*[@id=\"SubmitCreate\"]/span")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"id_gender2\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"customer_firstname\"]")).sendKeys("Komal");
		driver.findElement(By.xpath("//*[@id=\"customer_lastname\"]")).sendKeys("Vin");
		driver.findElement(By.xpath("//*[@id=\"passwd\"]")).sendKeys("Ganesh");
		driver.findElement(By.xpath("//*[@id=\"address1\"]")).sendKeys("Test");
		driver.findElement(By.xpath("//*[@id=\"city\"]")).sendKeys("Thane");
		Select drpState = new Select(driver.findElement(By.xpath("//*[@id=\"id_state\"]")));
		drpState.selectByVisibleText("Alaska");
		driver.findElement(By.xpath("//*[@id=\"postcode\"]")).sendKeys("12345");
		driver.findElement(By.xpath("//*[@id=\"phone_mobile\"]")).sendKeys("123456");
		driver.findElement(By.xpath("//*[@id=\"submitAccount\"]/span")).click();
	}
	
	
	@Then("^User Login with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_Login_with_komal_sherekar_gmail_com_and_password(String username,String password) throws Throwable {
		
		driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys(username);
		driver.findElement(By.xpath("//*[@id=\"passwd\"]")).sendKeys(password);
		driver.findElement(By.xpath("//*[@id=\"SubmitLogin\"]/span")).click();
		Thread.sleep(5000);
		
	}
	
	@Then("^User add two products to the cart$")
	public void user_add_two_products_to_the_cart() throws Throwable {
		
		driver.findElement(By.cssSelector("#block_top_menu > ul > li:nth-child(1) > a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"list\"]/a/i")).click();
		driver.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li[1]/div/div/div[3]/div/div[2]/a[1]/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[1]/span")).click();
		driver.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li[2]/div/div/div[3]/div/div[2]/a[1]/span")).click();
		//driver.findElement(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[1]/span")).click();
		driver.navigate().back();
		driver.navigate().forward();
		driver.navigate().refresh();
		Thread.sleep(5000);
	}
	
	@Then("^User completes the Checkout Process and verify order history$")
	public void user_completes_the_Checkout_Process_and_verify_order_history() throws Throwable {
		
		driver.findElement(By.xpath("//*[contains(text(),\"Cart\")]")).click();
		Thread.sleep(2000);
		String tProduct = driver.findElement(By.xpath("//*[@id=\"total_product\"]")).getText();
		String tShipping = driver.findElement(By.xpath("//*[@id=\"total_shipping\"]")).getText();
		String Tax = driver.findElement(By.xpath("//*[@id=\"total_tax\"]")).getText();
		String Total2 = driver.findElement(By.xpath("//*[@id=\"total_price\"]")).getText();
		String sum = tProduct+tShipping+Tax;
		if (sum.contentEquals(Total2)){
            System.out.println("Test Passed!");
        } else {
            System.out.println("Test Failed");
        }
		driver.findElement(By.xpath("//*[@id=\"center_column\"]/p[2]/a[1]/span")).click();
		driver.findElement(By.xpath("//*[@id=\"center_column\"]/form/p/button/span")).click();
		driver.findElement(By.xpath("//*[@id=\"cgv\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"form\"]/p/button/span")).click();
		driver.findElement(By.xpath("//*[@id=\"HOOK_PAYMENT\"]/div[1]/div/p/a/span")).click();
		driver.findElement(By.xpath("//*[@id=\"cart_navigation\"]/button/span")).click();
		driver.findElement(By.xpath("//*[@id=\"center_column\"]/p/a")).click();
		//Combining Test case verify order history.
		driver.findElement(By.xpath("//*[@id=\"order-list\"]/tbody/tr[1]/td[7]/a[1]/span")).click();
		String Total3 = driver.findElement(By.xpath("//*[@id=\"order-list\"]/tbody/tr[1]/td[3]/span")).getText();
		if (Total3.contentEquals(Total2)){
            System.out.println("Test Passed!");
        } else {
            System.out.println("Test Failed");
        }
	}

	
	@Then("^User Close Browser$")
	public void user_Close_Browser() throws Throwable {
	   driver.close();
	}
	
}
